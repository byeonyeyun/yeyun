from bmi_utils import calc_bmi, classify_bmi

def main():
cm = float(input('신장(cm)를 입력해주세요'))
kg = float(input('몸무게(kg)를 입력해주세요'))

bmi = calc_bmi(cm,kg)
result = calc_bmi(bmi)

print(f'당신의 BMI는 {bmi}이고 {result} 입니다.')