def calc_bmi(cm: float , kg: float ) -> float :
    m = cm/100
    bmi = round(kg/m**2,1)
    return bmi