def classify_bmi(bmi: float) -> str:
    if bmi >25.0:
        result = '비만'
    elif bmi > 23.0:
        result = '과체중'
    elif bmi > 18.5:
        result = '정상'
    else:
        result = '저체중'
    return result