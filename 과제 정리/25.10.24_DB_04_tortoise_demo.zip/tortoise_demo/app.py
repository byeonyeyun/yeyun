from datetime import datetime, timedelta
from tortoise import Tortoise, run_async
from config import TORTOISE_ORM
from models import Appointment,Doctor,Patient
import asyncio

async def main():
    await Tortoise.init(config=TORTOISE_ORM)
    await Tortoise.generate_schemas()

    dr_lee = await Doctor.create(name="이병헌", specialty="내과")
    dr_park = await Doctor.create(name="박명수", specialty="소아과")
    p_lee = await Patient.create(name="이동원", birth_date="1993-01-01", phone ='010-1234-1234')
    p_kim = await Patient.create(name="김민찬", birth_date="2000-05-10", phone = '010-1234-6543')
    appt1 = await Appointment.create(
        patient=p_lee, doctor=dr_lee,
        visit_date=datetime.now() + timedelta(days=1),
        note="초진 예약"
    )
    appt2 = await Appointment.create(
        patient=p_lee, doctor=dr_park,
        visit_date=datetime.now() + timedelta(days=2),
        note="소아과 상담"
    )   
    appointments = await Appointment.all()
    for appointments in appointment:
        print(appointments.id, appointment.name)

    one_doctor = await Doctor.get(id=dr_lee.id)
    print("단건 의사:", one_doctor)
    recent_patients = await Patient.filter(birth_date__gte="1990-01-01").order_by("name")
    print("조건 환자:", [str(p) for p in recent_patients])
    rows = await Appointment.all().select_related("patient","doctor")
    for a in rows:
        print(f"[예약 {a.id}] {a.patient.name} → {a.doctor.name} ({a.note})")
    lee_with_appts = await Patient.get(id=p_lee.id).prefetch_related("appointments")
    print("예약 수:", len(lee_with_appts.appointments))

    r_lee.specialty = "가정의학과"
    await dr_lee.save()
    p_lee.birth_date = "1994-02-02"
    await p_lee.save()
    appt1.note = "증상 업데이트: 기침/두통/몸살"
    appt1.reserved_at = appt1.reserved_at + timedelta(days=1)
    await appt1.save()
    updated = await Appointment.get(id=appt1.id).select_related("patient", "doctor")
    print(f"수정 후: [예약 {updated.id}] {updated.patient.name} → {updated.doctor.name} ({updated.note})")  

    await appt2.delete()
    print("삭제한 예약: ", appt2.id)
    await p_lee.delete()
    print("삭제한 환자: ", "이동원")
    await dr_park.delete()
    print("삭제한 의사: ", "박명수")

if __name__ == "__main__":
    asyncio.run(main())