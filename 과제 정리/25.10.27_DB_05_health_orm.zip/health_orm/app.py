import asyncio
from tortoise import Tortoise
from config import TORTOISE_ORM
from models import Patient, HealthMetric, Treatment


async def ex1():
    patient_id_check = 1
    patient = await Patient.get_or_none(id=patient_id_check)
    if not patient:
        print(f'{patient_id_check}는 없는 환자입니다.')
        return
    print(f'환자 이름: {patient.name}/ 환자 ID {patient_id_check}')

    recent_metrics = await HealthMetric.filter(patient_id=patient_id_check).order_by('-date').limit(3)
    if not recent_metrics:
        print('기록이 없습니다.')
        return

    for metric in recent_metrics:
        print(
            f"날짜: {metric.date}, "
            f"체중: {metric.weight}kg, "
            f"키: {metric.height}cm, "
            f"수축기 혈압: {metric.systolic}"
        )


async def ex2():
    patient_id_check = 3
    patient = await Patient.get_or_none(id=patient_id_check)

    if not patient:
        print(f'{patient_id_check}는 없는 환자입니다.')
        return
    print(f'환자 이름: {patient.name}/ 환자 ID {patient_id_check}')

    treatments = await Treatment.filter(patient_id=patient_id_check).select_related('drug').order_by('date').limit(3)
    if not treatments:
        print("기록이 없습니다.")
        return

    for t in treatments:
        drug_name = t.drug.drug_name if t.drug else "Unknown"
        drug_company = t.drug.drug_company if t.drug else "Unknown"
        print(
            f"날짜: {t.date}, "
            f"약물명: {drug_name}, "
            f"제약사: {drug_company}, "
            f"복용량: {t.dose}, "
            f"복용법: {t.prescription}"
        )


async def ex3():
    all_patients = await Patient.all()
    found_cnt = 0
    for patient in all_patients:
        latest_metric = await HealthMetric.filter(patient_id=patient.id).order_by('-date').first()
        if latest_metric and latest_metric.systolic and latest_metric.systolic > 140:
            found_cnt += 1
            print(
                f"=======위험한 환자=======\n"
                f"환자 ID: {patient.id}, "
                f"환자 이름: {patient.name}, "
                f"날짜: {latest_metric.date}, "
                f"수축기 혈압: {latest_metric.systolic}"
            )

    print(f"총 위험 환자 수: {found_cnt}")


async def main():
    try:
        await Tortoise.init(config=TORTOISE_ORM)
        await ex1()
        print()
        await ex2()
        print()
        await ex3()
    except Exception as e:
        print(f"Error: {e}")
    finally:
        await Tortoise.close_connections()


if __name__ == "__main__":
    asyncio.run(main())



