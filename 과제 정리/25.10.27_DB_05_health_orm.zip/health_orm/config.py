TORTOISE_ORM = {
    "connections": {
        "default": "mysql://root:00000000@localhost:3306/hospital5?charset=utf8mb4"
    },
    "apps": {
        "models": {
            "models": ["models"],
            "default_connection": "default",
        },
    },
}