const todoInput = document.querySelector("#todo-input");
const addBtn = document.querySelector("#add-btn");
const todoList = document.querySelector("#todo-list");

let todos = JSON.parse(localStorage.getItem("todos")) || [];

addBtn.addEventListener("click", addTodo);

function addTodo() {
    const todo = todoInput.value.trim();
    if (todo === "") return;

    todos.push(todo);
    localStorage.setItem("todos", JSON.stringify(todos));

    todoInput.value = "";
    renderTodos();
}

function renderTodos() {
    todoList.innerHTML = "";

    for (const [index, todo] of todos.entries()) {
        const li = document.createElement("li");
        li.className =
            "list-group-item d-flex justify-content-between align-items-center";
        li.textContent = todo;

        const deleteBtn = document.createElement("button");
        deleteBtn.className = "btn btn-sm btn-danger";
        deleteBtn.textContent = "삭제";
        deleteBtn.addEventListener("click", () => deleteTodo(index));

        li.appendChild(deleteBtn);
        todoList.appendChild(li);
    }
}

function deleteTodo(index) {
    todos.splice(index, 1);
    localStorage.setItem("todos", JSON.stringify(todos));
    renderTodos();
}

renderTodos();


